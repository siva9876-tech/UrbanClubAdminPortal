import services.*;
import models.*;
import exceptions.*;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Sample Data
        try {
            DataStore.users.add(new User("u1", "Rahul", "rahul@gmail.com"));
            DataStore.workers.add(new Worker("w1", "Ankit", "ankit@gmail.com", "Electrician"));
            DataStore.bookings.add(new Booking("b1", "u1", "w1", "Fan Repair", 500, "completed"));
            DataStore.feedbacks.add(new Feedback("b1", "Great service!", 5));
        } catch (Exception e) {
            System.out.println("⚠️ Data load failed: " + e.getMessage());
        }

        try {
            System.out.println("🔐 Admin Login");

            System.out.print("📧 Enter Email: ");
            String email = sc.nextLine();
            if (!email.endsWith("@gmail.com")) {
                throw new InvalidEmailException("📛 Email must be a valid @gmail.com address.");
            }

            System.out.print("🔑 Enter Password (alphanumeric): ");
            String password = sc.nextLine();
            if (!password.matches("[A-Za-z0-9]+")) {
                throw new InvalidPasswordException("📛 Password must be alphanumeric.");
            }

            if (!password.equals("admin123")) {
                throw new InvalidPasswordException("❌ Incorrect password.");
            }

            System.out.println("✅ Login successful!");

            int choice;
            do {
                System.out.println("\n📋 Admin Dashboard");
                System.out.println("1. 👥 View Users");
                System.out.println("2. 👷 View Workers");
                System.out.println("3. 📦 View Bookings");
                System.out.println("4. 💬 View Feedback");
                System.out.println("0. 🔚 Logout");
                System.out.print("Enter your choice: ");
                choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {
                    case 1:
                        for (User user : DataStore.users) {
                            System.out.println(user.getDetails());
                        }
                        break;
                    case 2:
                        for (Worker worker : DataStore.workers) {
                            System.out.println(worker.getDetails());
                        }
                        break;
                    case 3:
                        for (Booking booking : DataStore.bookings) {
                            System.out.println(booking.getDetails());
                        }
                        break;
                    case 4:
                        for (Feedback feedback : DataStore.feedbacks) {
                            System.out.println(feedback.getDetails());
                        }
                        break;
                    case 0:
                        System.out.println("👋 Logged out.");
                        break;
                    default:
                        System.out.println("❗ Invalid option.");
                }
            } while (choice != 0);

        } catch (InvalidEmailException | InvalidPasswordException e) {
            System.out.println("❌ Login Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("⚠️ Unexpected Error: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
