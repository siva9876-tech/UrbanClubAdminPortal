package models;
import exceptions.InvalidUserException;

public class User extends Person {
    public User(String id, String name, String email) throws InvalidUserException {
        super(id, name, email);
        if (id == null || id.isEmpty() || name == null || name.isEmpty()) {
            throw new InvalidUserException("🧑❌ User ID and name must not be empty.");
        }
        if (email == null || !email.endsWith("@gmail.com")) {
            throw new InvalidUserException("📛 Invalid user email. Must be a @gmail.com address.");
        }
    }

    @Override
    public String getDetails() {
        return "🧑 User ID: " + id + ", Name: " + name + ", Email: " + email;
    }
}
