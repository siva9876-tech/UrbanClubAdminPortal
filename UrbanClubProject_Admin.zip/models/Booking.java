package models;

public class Booking implements Displayable {
    private String id;
    private String userId;
    private String workerId;
    private String service;
    private double amount;
    private String status;

    public Booking(String id, String userId, String workerId, String service, double amount, String status) {
        this.id = id;
        this.userId = userId;
        this.workerId = workerId;
        this.service = service;
        this.amount = amount;
        this.status = status;
    }

    public double getAmount() { return amount; }
    public String getStatus() { return status; }
    public String getUserId() { return userId; }
    public String getWorkerId() { return workerId; }

    @Override
    public String getDetails() {
        return "📦 Booking ID: " + id + ", Service: " + service + ", Amount: ₹" + amount +
               ", Status: " + status + ", User ID: " + userId + ", Worker ID: " + workerId;
    }
}
