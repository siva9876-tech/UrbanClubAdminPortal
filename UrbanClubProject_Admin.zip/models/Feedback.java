package models;
import exceptions.InvalidFeedbackException;

public class Feedback implements Displayable {
    private String bookingId;
    private String comment;
    private int rating;

    public Feedback(String bookingId, String comment, int rating) throws InvalidFeedbackException {
        if (bookingId == null || bookingId.isEmpty()) {
            throw new InvalidFeedbackException("💬❌ Booking ID cannot be empty.");
        }
        if (comment == null || comment.trim().isEmpty()) {
            throw new InvalidFeedbackException("💬❌ Feedback comment cannot be empty.");
        }
        if (rating < 1 || rating > 5) {
            throw new InvalidFeedbackException("⭐ Rating must be between 1 and 5.");
        }
        this.bookingId = bookingId;
        this.comment = comment;
        this.rating = rating;
    }

    @Override
    public String getDetails() {
        return "💬 Booking ID: " + bookingId + ", Comment: " + comment + ", Rating: " + rating + "⭐";
    }
}
