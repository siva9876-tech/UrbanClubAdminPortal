package models;
import exceptions.InvalidWorkerException;

public class Worker extends Person {
    private String skill;
    private boolean active = true; // default

    public Worker(String id, String name, String email, String skill) throws InvalidWorkerException {
        super(id, name, email);
        if (id == null || id.isEmpty() || name == null || name.isEmpty() || skill == null || skill.isEmpty()) {
            throw new InvalidWorkerException("👷❌ Worker fields must not be empty.");
        }
        if (!email.endsWith("@gmail.com")) {
            throw new InvalidWorkerException("📛 Invalid worker email. Must be a @gmail.com address.");
        }
        this.skill = skill;
    }

    public String getSkill() {
        return skill;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public String getDetails() {
        return "👷 Worker ID: " + id + ", Name: " + name + ", Skill: " + skill + ", Email: " + email + ", Active: " + active;
    }
}
