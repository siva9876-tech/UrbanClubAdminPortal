package models;
public interface Displayable {
    String getDetails();
}
