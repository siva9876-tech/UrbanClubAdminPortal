package services;

import models.*;
import java.util.*;

public class DataStore {
    public static List<User> users = new ArrayList<>();
    public static List<Worker> workers = new ArrayList<>();
    public static List<Booking> bookings = new ArrayList<>();
    public static List<Feedback> feedbacks = new ArrayList<>();
}