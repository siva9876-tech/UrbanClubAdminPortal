package services;

import models.*;

public class AdminService {

    public void viewAllUsers() {
        System.out.println("\n👥 All Users:");
        DataStore.users.forEach(System.out::println);
    }

    public void viewAllWorkers() {
        System.out.println("\n🧰 All Workers:");
        DataStore.workers.forEach(System.out::println);
    }

    public void viewAllBookings() {
        System.out.println("\n📦 All Bookings:");
        DataStore.bookings.forEach(System.out::println);
    }

    public void showPlatformReports() {
        double totalEarnings = DataStore.bookings.stream()
                .filter(b -> b.getStatus().equals("completed"))
                .mapToDouble(Booking::getAmount).sum();

        long activeWorkers = DataStore.workers.stream().filter(Worker::isActive).count();

        System.out.println("\n📊 Platform Reports:");
        System.out.println("💰 Total Earnings: ₹" + totalEarnings);
        System.out.println("🧍‍♂️ Active Workers: " + activeWorkers);
    }

    public void monitorFeedback() {
        System.out.println("\n⭐ Feedbacks:");
        DataStore.feedbacks.forEach(System.out::println);
    }

    public void deleteUser(String userId) {
        DataStore.users.removeIf(user -> user.getId().equals(userId));
        System.out.println("🗑️ User deleted: " + userId);
    }

    public void deleteWorker(String workerId) {
        DataStore.workers.removeIf(worker -> worker.getId().equals(workerId));
        System.out.println("🗑️ Worker deleted: " + workerId);
    }
}