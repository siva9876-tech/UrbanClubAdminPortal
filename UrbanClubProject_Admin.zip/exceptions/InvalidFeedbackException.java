package exceptions;
public class InvalidFeedbackException extends Exception {
    public InvalidFeedbackException(String message) {
        super(message);
    }
}
