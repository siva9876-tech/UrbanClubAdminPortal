package exceptions;
public class InvalidWorkerException extends Exception {
    public InvalidWorkerException(String message) {
        super(message);
    }
}
